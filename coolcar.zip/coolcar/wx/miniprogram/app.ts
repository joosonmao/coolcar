// import { getSetting, getUserInfo } from "./utils/util"

// //
// let resolveUserInfo: (value: WechatMiniprogram.UserInfo | PromiseLike<WechatMiniprogram.UserInfo>) => void
// let rejectUserInfo: (reason?: any) => void
// // let test:number
// // console.log(test)
// // app.ts
// App<IAppOption>({
//   globalData: {
//     userInfo:new Promise((resolve,reject)=>{
//       resolveUserInfo=resolve
//       rejectUserInfo=reject
//     })
//     // userInfo:new Promise((resolve,reject)=>{
//     //       // 获取用户信息的Promise的版本
//     // getSetting().then(res=>{
//     //   if(res.authSetting['scope.userInfo']){
//     //     return getUserInfo()
//     //   }
//     //   return undefined
//     // }).then(res=>{
//     //   if(!res){
//     //     return
//     //   }
//     //   // 通知页面我获得了用户信息
//     //   resolve(res.userInfo)
//     //   // // ?的意思
//     //   // // 如果ｒｅｓ有则获取res.userInfo
//     //   // // 如果ｒｅｓ还没有返回，则res.userInfo是undefined
//     //   // this.globalData.userInfo=res?.userInfo
//     //   // // 通知页面我获得了用户信息，即告诉index.ts
//     //   // if(this.userInfoReadyCallback){
//     //   //   this.userInfoReadyCallback(res)
//     //   // }
//     // }).catch(err=>reject(err))

//     // })
//   },

   
  

//   async onLaunch() {
//     console.log('onLaunch')
//     // 展示本地存储能力
//     const logs = wx.getStorageSync('logs') || []
//     logs.unshift(Date.now())
//     wx.setStorageSync('logs', logs)

//     // 登录
//     wx.login({
//       success: res => {
//         console.log(res.code)
//         // 发送 res.code 到后台换取 openId, sessionKey, unionId
//       },
//     })
//     // 获取用户信息的Promise的版本
//     try{
//        const setting = await getSetting()
//     if (setting.authSetting['scope.userInfo']) {
//       const userInfoRes = await getUserInfo()
//       resolveUserInfo(userInfoRes.userInfo)
//     }}catch(err){
//       rejectUserInfo(err)
//     }
   
//     // getSetting().then(res => {
//     //   if (res.authSetting['scope.userInfo']) {
//     //     return getUserInfo()
//     //   }
//     //   return undefined
//     // }).then(res => {
//     //   if (!res) {
//     //     return
//     //   }
//       // 通知页面我获得了用户信息
//       // resolveUserInfo(res.userInfo)
//       // // ?的意思
//       // // 如果ｒｅｓ有则获取res.userInfo
//       // // 如果ｒｅｓ还没有返回，则res.userInfo是undefined
//       // this.globalData.userInfo=res?.userInfo
//       // // 通知页面我获得了用户信息，即告诉index.ts
//       // if(this.userInfoReadyCallback){
//       //   this.userInfoReadyCallback(res)
//       // }
//     // }).catch(err => rejectUserInfo(err))


//   },
//   resolveUserInfo(userInfo: WechatMiniprogram.UserInfo){
//     resolveUserInfo(userInfo)
//   }
// })
