"use strict";
Page({
    data: {
        showPath: true,
        values: [
            {
                name: 'john',
                id: 1,
            },
            {
                name: 'ava',
                id: 2,
            },
            {
                name: 'lin',
                id: 3,
            }
        ]
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGVhcm5jc3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsZWFybmNzcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsSUFBSSxDQUFDO0lBQ0gsSUFBSSxFQUFDO1FBQ0gsUUFBUSxFQUFDLElBQUk7UUFDYixNQUFNLEVBQUM7WUFDTDtnQkFDQSxJQUFJLEVBQUMsTUFBTTtnQkFDWCxFQUFFLEVBQUMsQ0FBQzthQUNMO1lBRUg7Z0JBQ0UsSUFBSSxFQUFDLEtBQUs7Z0JBQ1YsRUFBRSxFQUFDLENBQUM7YUFDTDtZQUNEO2dCQUNFLElBQUksRUFBQyxLQUFLO2dCQUNWLEVBQUUsRUFBQyxDQUFDO2FBQ0w7U0FDRTtLQUNGO0NBQ0YsQ0FBQyxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiUGFnZSh7XG4gIGRhdGE6e1xuICAgIHNob3dQYXRoOnRydWUsXG4gICAgdmFsdWVzOltcbiAgICAgIHtcbiAgICAgIG5hbWU6J2pvaG4nLFxuICAgICAgaWQ6MSxcbiAgICB9XG4gICxcbiAge1xuICAgIG5hbWU6J2F2YScsXG4gICAgaWQ6MixcbiAgfSxcbiAge1xuICAgIG5hbWU6J2xpbicsXG4gICAgaWQ6MyxcbiAgfVxuICAgIF1cbiAgfVxufSlcbiJdfQ==