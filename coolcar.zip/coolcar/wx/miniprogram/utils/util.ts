export const formatTime = (date: Date) => {
    // const year = date.getFullYear()
    // const month = date.getMonth() + 1
    // const day = date.getDate()
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()

    return (
        // [year, month, day].map(formatNumber).join('/') +
        // ' ' +
        [hour, minute, second].map(formatNumber).join(':')
    )
}

const formatNumber = (n: number) => {
    const s = n.toString()
    return s[1] ? s : '0' + s
}

// export表示可以给外面使用的
export function getSetting(): Promise<WechatMiniprogram.GetSettingSuccessCallbackResult> {
    return new Promise((resolve, reject) => {
        wx.getSetting({
            // 成功了，通过resole传递res告诉外界成功了
            // success:res=>resolve(res),
            // fail:err=>reject(err),
            success: resolve,
            fail: reject,
        })
    })
}

export function getUserInfo(): Promise<WechatMiniprogram.GetUserProfileSuccessCallbackResult> {
    return new Promise((resolve, reject) => {
        wx.getUserProfile({
            lang:'zh_CN',
            desc:"user login",
            success:res=>{
              resolve(res)
            },
            fail: reject,
        })
    })
}

// export function getUserInfo(): Promise<WechatMiniprogram.GetUserInfoSuccessCallbackResult> {
//     return new Promise((resolve, reject) => {
//         wx.getUserInfo({
//             success: resolve,
//             fail: reject,
//         })
//     })
// }

